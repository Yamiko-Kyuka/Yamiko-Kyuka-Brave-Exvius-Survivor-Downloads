import {GACHA_COST,drawSkin,equipSkin,gachaOdds,gachaPool,gachaUnlocked,normalizeCosmetics} from './gacha.js';
import {AnimationPlayer,clipFor} from './animation.js';
import {GachaPresentation} from './gacha-presentation.js';
import {revealFraming} from './hero-unlock-reveal.js';
export class GachaView{
 constructor({root,getSave,persist,heroes,loadVariant,loadEntity,cache,onEquip,dialog,helpDialog}){
  Object.assign(this,{root,getSave,persist,heroes,loadVariant,cache,onEquip,busy:false,elapsed:0,skin:null,preview:null,serial:0,helpDialog});
  this.$=id=>root.querySelector('#'+id);this.$('gachaMachine').onclick=()=>this.spin();this.$('gachaPrice').onclick=()=>this.spin();this.$('gachaEquip').onclick=async()=>{if(this.skin&&equipSkin(this.getSave(),this.skin.heroId,this.skin.id)){await persist();this.onEquip?.();this.render();}};
  this.presentation=new GachaPresentation({dialog,machine:this.$('gachaMachine'),loadEntity,cache,onReveal:()=>this.reveal(),onDismiss:()=>{this.busy=false;this.render();},onEquip:()=>this.$('gachaEquip').click()});
  for(const button of document.querySelectorAll('[data-gacha-help]'))button.onclick=()=>this.openHelp(button.dataset.gachaHelp);helpDialog.querySelector('#gachaHelpClose').onclick=()=>helpDialog.close();helpDialog.addEventListener('cancel',e=>{e.preventDefault();helpDialog.close();});
  for(const h of heroes){const o=document.createElement('option');o.value=h.id;o.textContent=h.name;this.$('gachaHeroFilter').append(o);}this.$('gachaHeroFilter').onchange=()=>this.collection();
 }
 render(){
  const save=this.getSave(),open=gachaUnlocked(save),pool=gachaPool(save),cosmetics=normalizeCosmetics(save.cosmetics),machine=this.$('gachaMachine');
  machine.disabled=this.busy||!open||save.coins<GACHA_COST||!pool.length;machine.setAttribute('aria-label',this.busy?'Tirage en cours':'Tourner le Gachapon · 20 000 gils');
  this.$('gachaPrice').disabled=machine.disabled;this.$('gachaPrice').textContent=this.busy?'TIRAGE…':!open?'VERROUILLÉ':!pool.length?'INDISPONIBLE':'TOURNER · 20 000 GILS';
  const acquired=cosmetics.owned.length-this.heroes.length;this.$('gachaOwned').textContent='Collection · '+acquired+' / '+pool.length;
  this.$('gachaOdds').replaceChildren();for(const r of gachaOdds(save)){const chip=document.createElement('span');chip.style.color=r.color;chip.textContent=r.name+' '+(r.probability*100).toLocaleString('fr-FR',{maximumFractionDigits:2})+' %';this.$('gachaOdds').append(chip);}
  if(this.skin){const ownedHero=save.unlocked.includes(this.skin.heroId);this.$('gachaEquip').disabled=!ownedHero;this.$('gachaEquip').textContent=ownedHero?(cosmetics.selected[this.skin.heroId]===this.skin.id?'APPARENCE ÉQUIPÉE':'ÉQUIPER CETTE APPARENCE'):'HÉROS À DÉBLOQUER DANS SUCCÈS';}
  if(this.presentation.revealed&&this.presentation.active)this.updatePresentation();this.presentation.prepare();this.collection();
 }
 openHelp(topic){
  const topics={
   rules:['Le Gacha',['Cliquez sur la machine ou sur Tourner. Le Mog tourne la molette, apporte la capsule et révèle votre apparence.','Les apparences changent le modèle et ses animations, sans modifier les statistiques ni l’arme du héros.']],
   cost:['Prix et doublons',['Un tirage coûte 20 000 gils. Il faut disposer de la mise entière pour lancer la machine.','Si l’apparence est déjà possédée, 10 000 gils sont remboursés immédiatement. Une seule copie est conservée.']],
   rarities:['Raretés et probabilités',['Normal : 50 % · Magique : 27 % · Rare : 15 % · Épique : 6 % · Légendaire : 2 %.','Les apparences déjà possédées peuvent retomber. La collection ne change pas les probabilités.','La section Collection indique le taux individuel de chaque apparence.']],
   collection:['Votre collection',['Le compteur indique les apparences gagnées parmi les 424 formes et costumes du Gacha. Les 38 apparences classiques sont gratuites et ne sont pas tirées.','Le détail de la collection montre les apparences possédées et les taux individuels.','Un skin ne débloque pas son héros. Récupérez le héros dans Succès, puis choisissez le skin sous son modèle dans la sélection des personnages.']],
   result:['Cette apparence',['Ce skin change uniquement le modèle et ses animations. Les statistiques et l’arme de base restent celles du héros.','Équipez-le ici ou sous le modèle du héros dans la sélection des personnages. Si le héros est encore verrouillé, débloquez-le dans Succès.']]
  };
  const [title,paragraphs]=topics[topic]||topics.rules,body=this.helpDialog.querySelector('#gachaHelpBody');this.helpDialog.querySelector('#gachaHelpTitle').textContent=title;body.replaceChildren();for(const text of paragraphs){const p=document.createElement('p');p.textContent=text;body.append(p);}if(!this.helpDialog.open)this.helpDialog.showModal();this.helpDialog.querySelector('#gachaHelpClose').focus();
 }
 updatePresentation(){const cosmetics=normalizeCosmetics(this.getSave().cosmetics);this.presentation.updateReward({skin:this.skin,hero:this.heroes.find(h=>h.id===this.skin.heroId),canEquip:this.getSave().unlocked.includes(this.skin.heroId),equipped:cosmetics.selected[this.skin.heroId]===this.skin.id});}
 collection(){
  const save=this.getSave(),owned=new Set(normalizeCosmetics(save.cosmetics).owned),odds=gachaOdds(save),heroId=this.$('gachaHeroFilter').value;
  import('./skin-catalog.js').then(({skinCatalog})=>{this.$('gachaCollection').replaceChildren();for(const skin of skinCatalog.filter(s=>s.heroId===heroId)){
   const r=odds.find(r=>r.id===skin.rarity),row=document.createElement('div');row.className='skin-collection-row';row.style.setProperty('--skin-color',r.color);const name=document.createElement('span'),rate=document.createElement('small');name.textContent=skin.name;rate.textContent=skin.classic?'✓ CLASSIQUE':(owned.has(skin.id)?'✓ POSSÉDÉE · ':'')+r.name+' · '+(r.probability/Math.max(1,r.count)*100).toLocaleString('fr-FR',{maximumFractionDigits:3})+' % par tirage';row.append(name,rate);this.$('gachaCollection').append(row);
  }});
 }
 spin(){
  if(this.busy)return;const skin=drawSkin(this.getSave());if(!skin){this.render();return;}
  this.skin=skin;this.busy=true;this.elapsed=0;this.preview=null;this.$('gachaPreview').getContext('2d').clearRect(0,0,600,320);this.serial++;this.$('gachaResult').hidden=true;this.$('gachaRefund').hidden=true;this.$('gachaMachine').dataset.phase='spinning';const rarity=gachaOdds(this.getSave()).find(r=>r.id===skin.rarity);this.$('gachaMachine').style.setProperty('--capsule-color',rarity.color);this.$('gachaNotice').textContent='Une capsule se prépare…';
  this.persist();this.presentation.start(skin);this.render();
 }
 async reveal(){
  const skin=this.skin,serial=this.serial,hero=this.heroes.find(h=>h.id===skin.heroId),rarity=gachaOdds(this.getSave()).find(r=>r.id===skin.rarity);this.$('gachaMachine').dataset.phase='reveal';this.$('gachaResult').hidden=false;this.$('gachaWelcome').hidden=true;this.$('gachaResult').style.setProperty('--skin-color',rarity.color);this.$('gachaSkinRarity').textContent='✦ '+rarity.name;this.$('gachaSkinName').textContent=skin.name;this.$('gachaSkinHero').textContent=hero.name;this.$('gachaRefund').hidden=!skin.duplicate;this.$('gachaRefund').textContent=skin.duplicate?'DOUBLON · + '+skin.refund.toLocaleString('fr-FR')+' GILS REMBOURSÉS':'';this.$('gachaNotice').textContent=skin.duplicate?'Apparence déjà possédée · moitié de la mise remboursée.':'Nouvelle apparence obtenue !';this.render();this.updatePresentation();this.presentation.$('summonPreviewStatus').textContent='Le cristal révèle votre apparence…';
  try{const variant=await this.loadVariant(skin),idle=clipFor(variant,'idle'),anim=new AnimationPlayer(variant);await this.cache.preload([idle]);if(serial!==this.serial)return;this.preview={anim,framing:revealFraming([idle],600,320)};this.presentation.$('summonPreviewStatus').textContent='';}catch{if(serial!==this.serial)return;this.presentation.$('summonPreviewStatus').textContent='Aperçu indisponible. Votre récompense est enregistrée.';this.$('gachaNotice').textContent=(skin.duplicate?'Doublon remboursé.':'Apparence ajoutée à votre collection.')+' Aperçu indisponible pour le moment.';}
 }
 tick(dt){
  this.presentation.tick(dt);if(!this.root.hidden)this.presentation.drawHost(this.$('gachaHost'),dt);this.elapsed=this.presentation.elapsed;if(this.busy&&!this.presentation.revealed)this.$('gachaMachine').dataset.phase=this.presentation.phase||'spinning';
  const p=this.preview;if(this.root.hidden||!p)return;const clip=p.anim.clip;if(!this.cache.ready(clip,p.anim.elapsed,{loop:!p.anim.busy})){this.cache.loadClip(clip,p.anim.elapsed,{loop:!p.anim.busy}).catch(()=>{});return;}p.anim.update(dt);if(!this.cache.ready(p.anim.clip,p.anim.elapsed,{loop:!p.anim.busy})){this.cache.loadClip(p.anim.clip,p.anim.elapsed,{loop:!p.anim.busy}).catch(()=>{});return;}for(const canvas of [this.$('gachaPreview'),...(this.presentation.active&&this.presentation.revealed?[this.presentation.$('summonSkin')]:[])]){const ctx=canvas.getContext('2d');ctx.clearRect(0,0,600,320);this.cache.draw(ctx,p.anim.clip,p.anim.elapsed,p.framing.x,p.framing.y,{scale:p.framing.scale,loop:!p.anim.busy});}
 }
}
